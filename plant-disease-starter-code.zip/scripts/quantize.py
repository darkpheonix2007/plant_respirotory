from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
from torch import nn

sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from plant_disease.models import build_model


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model = build_model(checkpoint["model_name"], len(checkpoint["class_names"]), pretrained=False)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    quantized = torch.quantization.quantize_dynamic(model, {nn.Linear}, dtype=torch.qint8)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            **checkpoint,
            "model_state": quantized.state_dict(),
            "quantized": "dynamic_linear",
        },
        args.out,
    )

    original_mb = args.checkpoint.stat().st_size / (1024 * 1024)
    quantized_mb = args.out.stat().st_size / (1024 * 1024)
    print(f"Original: {original_mb:.2f} MB")
    print(f"Quantized: {quantized_mb:.2f} MB")


if __name__ == "__main__":
    main()


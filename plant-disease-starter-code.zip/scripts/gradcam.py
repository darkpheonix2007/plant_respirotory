from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image

sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from plant_disease.data import image_transform
from plant_disease.models import gradcam_target_layer, model_from_checkpoint


class GradCAM:
    def __init__(self, model: torch.nn.Module, target_layer: torch.nn.Module) -> None:
        self.model = model
        self.activations = None
        self.gradients = None
        target_layer.register_forward_hook(self._save_activation)
        target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, _module, _inputs, output) -> None:
        self.activations = output.detach()

    def _save_gradient(self, _module, _grad_input, grad_output) -> None:
        self.gradients = grad_output[0].detach()

    def __call__(self, image_tensor: torch.Tensor, class_idx: int | None = None) -> tuple[np.ndarray, int]:
        logits = self.model(image_tensor)
        if class_idx is None:
            class_idx = int(logits.argmax(dim=1).item())
        score = logits[:, class_idx].sum()
        self.model.zero_grad()
        score.backward()

        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1).squeeze()
        cam = torch.relu(cam)
        cam = cam - cam.min()
        cam = cam / (cam.max() + 1e-8)
        return cam.cpu().numpy(), class_idx


def overlay_cam(image: Image.Image, cam: np.ndarray) -> np.ndarray:
    rgb = np.array(image.convert("RGB"))
    cam_resized = cv2.resize(cam, (rgb.shape[1], rgb.shape[0]))
    heatmap = cv2.applyColorMap(np.uint8(255 * cam_resized), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    blended = np.uint8(0.55 * rgb + 0.45 * heatmap)
    return blended


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device)
    class_names = checkpoint["class_names"]
    model = model_from_checkpoint(checkpoint, device)

    image = Image.open(args.image).convert("RGB")
    transform = image_transform(checkpoint.get("image_size", 224), train=False)
    tensor = transform(image).unsqueeze(0).to(device)
    gradcam = GradCAM(model, gradcam_target_layer(model, checkpoint["model_name"]))
    cam, class_idx = gradcam(tensor)
    blended = overlay_cam(image, cam)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(blended).save(args.out)
    print(f"Predicted class: {class_names[class_idx]}")
    print(f"Saved Grad-CAM: {args.out}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from plant_disease.config import get_crop_config
from plant_disease.data import ManifestDataset, folder_manifest, image_transform, read_manifest
from plant_disease.metrics import save_metrics
from plant_disease.models import model_from_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--split-csv", type=Path)
    parser.add_argument("--split", default="test")
    parser.add_argument("--folder", type=Path)
    parser.add_argument("--crop", choices=["tomato", "potato"], default="tomato")
    parser.add_argument("--label-map", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=2)
    args = parser.parse_args()

    if not args.split_csv and not args.folder:
        raise ValueError("Pass either --split-csv or --folder.")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device)
    class_names = checkpoint["class_names"]
    class_to_idx = {name: idx for idx, name in enumerate(class_names)}

    if args.folder:
        crop_classes = get_crop_config(args.crop).classes
        manifest = folder_manifest(args.folder, crop_classes, args.label_map)
        manifest = manifest[manifest["class_name"].isin(class_names)].copy()
    else:
        manifest = read_manifest(args.split_csv, args.split)

    dataset = ManifestDataset(
        manifest,
        class_to_idx,
        image_transform(checkpoint.get("image_size", 224), train=False),
    )
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)
    model = model_from_checkpoint(checkpoint, device)

    y_true, y_pred, rows = [], [], []
    with torch.no_grad():
        for images, labels, paths in tqdm(loader, desc="Evaluating"):
            images = images.to(device)
            logits = model(images)
            probabilities = torch.softmax(logits, dim=1)
            preds = probabilities.argmax(dim=1).cpu()
            y_true.extend(labels.tolist())
            y_pred.extend(preds.tolist())
            for path, label, pred, probs in zip(paths, labels, preds, probabilities.cpu()):
                rows.append(
                    {
                        "path": path,
                        "true": class_names[int(label)],
                        "pred": class_names[int(pred)],
                        "confidence": float(probs[int(pred)]),
                    }
                )

    metrics = save_metrics(y_true, y_pred, class_names, args.out)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    import pandas as pd

    pd.DataFrame(rows).to_csv(args.out / "predictions.csv", index=False)
    print(json.dumps({"macro_f1": metrics["macro_f1"], "weighted_f1": metrics["weighted_f1"]}, indent=2))


if __name__ == "__main__":
    main()

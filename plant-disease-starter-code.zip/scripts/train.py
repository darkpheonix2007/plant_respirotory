from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from tqdm import tqdm

sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from plant_disease.data import ManifestDataset, image_transform, read_manifest
from plant_disease.metrics import save_metrics
from plant_disease.models import build_model


def run_epoch(model, loader, criterion, optimizer, device, train: bool) -> tuple[float, list[int], list[int]]:
    model.train(train)
    total_loss = 0.0
    y_true, y_pred = [], []
    for images, labels, _ in tqdm(loader, leave=False):
        images = images.to(device)
        labels = labels.to(device)
        with torch.set_grad_enabled(train):
            logits = model(images)
            loss = criterion(logits, labels)
            if train:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
        total_loss += loss.item() * images.size(0)
        y_true.extend(labels.cpu().tolist())
        y_pred.extend(logits.argmax(dim=1).cpu().tolist())
    return total_loss / len(loader.dataset), y_true, y_pred


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--split-csv", type=Path, required=True)
    parser.add_argument("--model", choices=["custom_cnn", "resnet18", "mobilenet_v2"], required=True)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--no-pretrained", action="store_true")
    args = parser.parse_args()

    run_dir = args.run_dir or Path("runs") / args.model
    run_dir.mkdir(parents=True, exist_ok=True)

    train_df = read_manifest(args.split_csv, "train")
    val_df = read_manifest(args.split_csv, "val")
    class_names = sorted(train_df["class_name"].unique().tolist())
    class_to_idx = {name: idx for idx, name in enumerate(class_names)}

    train_ds = ManifestDataset(train_df, class_to_idx, image_transform(args.image_size, train=True))
    val_ds = ManifestDataset(val_df, class_to_idx, image_transform(args.image_size, train=False))
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(args.model, len(class_names), pretrained=not args.no_pretrained).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)

    best_f1 = -1.0
    history = []
    for epoch in range(1, args.epochs + 1):
        train_loss, train_true, train_pred = run_epoch(model, train_loader, criterion, optimizer, device, True)
        val_loss, val_true, val_pred = run_epoch(model, val_loader, criterion, optimizer, device, False)
        metrics = save_metrics(val_true, val_pred, class_names, run_dir / "val_latest")
        row = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_loss": val_loss,
            "val_macro_f1": metrics["macro_f1"],
            "val_weighted_f1": metrics["weighted_f1"],
        }
        history.append(row)
        print(json.dumps(row))

        if metrics["macro_f1"] > best_f1:
            best_f1 = metrics["macro_f1"]
            torch.save(
                {
                    "model_name": args.model,
                    "model_state": model.state_dict(),
                    "class_names": class_names,
                    "image_size": args.image_size,
                    "best_macro_f1": best_f1,
                },
                run_dir / "best.pt",
            )

    (run_dir / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()


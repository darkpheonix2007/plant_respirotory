from __future__ import annotations

import argparse
import json
import random
import sys
from collections import defaultdict
from pathlib import Path

import imagehash
import pandas as pd
from PIL import Image
from tqdm import tqdm

sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from plant_disease.config import IMAGE_EXTENSIONS, get_crop_config


class DisjointSet:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: int, right: int) -> None:
        root_left = self.find(left)
        root_right = self.find(right)
        if root_left != root_right:
            self.parent[root_right] = root_left


class BKTree:
    def __init__(self) -> None:
        self.root = None
        self.nodes = []

    @staticmethod
    def distance(left: int, right: int) -> int:
        return (left ^ right).bit_count()

    def add(self, value: int, index: int) -> None:
        node = {"value": value, "indices": [index], "children": {}}
        if self.root is None:
            self.root = 0
            self.nodes.append(node)
            return

        current = self.root
        while True:
            current_node = self.nodes[current]
            distance = self.distance(value, current_node["value"])
            if distance == 0:
                current_node["indices"].append(index)
                return
            child = current_node["children"].get(distance)
            if child is None:
                current_node["children"][distance] = len(self.nodes)
                self.nodes.append(node)
                return
            current = child

    def query(self, value: int, threshold: int) -> list[int]:
        if self.root is None:
            return []
        matches = []
        stack = [self.root]
        while stack:
            node_index = stack.pop()
            node = self.nodes[node_index]
            distance = self.distance(value, node["value"])
            if distance <= threshold:
                matches.extend(node["indices"])
            low = distance - threshold
            high = distance + threshold
            for child_distance, child_index in node["children"].items():
                if low <= child_distance <= high:
                    stack.append(child_index)
        return matches


def image_paths_for_classes(data_root: Path, class_names: list[str]) -> list[tuple[Path, str]]:
    rows = []
    for class_name in class_names:
        class_dir = data_root / class_name
        if not class_dir.exists():
            raise FileNotFoundError(f"Missing class folder: {class_dir}")
        for path in sorted(class_dir.rglob("*")):
            if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS:
                rows.append((path.resolve(), class_name))
    return rows


def compute_hash(path: Path) -> str:
    with Image.open(path) as image:
        return str(imagehash.phash(image.convert("RGB")))


def group_near_duplicates(hashes: list[str], threshold: int) -> list[int]:
    dsu = DisjointSet(len(hashes))
    tree = BKTree()
    for index, value in enumerate(tqdm(hashes, desc="Grouping near-duplicates")):
        hash_int = int(value, 16)
        for match_index in tree.query(hash_int, threshold):
            dsu.union(index, match_index)
        tree.add(hash_int, index)
    roots = [dsu.find(i) for i in range(len(hashes))]
    remap = {root: idx for idx, root in enumerate(sorted(set(roots)))}
    return [remap[root] for root in roots]


def assign_splits(
    labels: list[str],
    group_ids: list[int],
    val_size: float,
    test_size: float,
    seed: int,
) -> list[str]:
    rng = random.Random(seed)
    group_to_label = {}
    for label, group_id in zip(labels, group_ids):
        group_to_label.setdefault(group_id, label)

    label_to_groups = defaultdict(list)
    for group_id, label in group_to_label.items():
        label_to_groups[label].append(group_id)

    group_split = {}
    for label, groups in label_to_groups.items():
        rng.shuffle(groups)
        n_total = len(groups)
        n_test = max(1, round(n_total * test_size)) if n_total >= 3 else 0
        n_val = max(1, round(n_total * val_size)) if n_total >= 3 else 0
        test_groups = set(groups[:n_test])
        val_groups = set(groups[n_test : n_test + n_val])
        for group_id in groups:
            if group_id in test_groups:
                group_split[group_id] = "test"
            elif group_id in val_groups:
                group_split[group_id] = "val"
            else:
                group_split[group_id] = "train"
    return [group_split[group_id] for group_id in group_ids]


def plain_count_dict(values: dict) -> dict:
    clean = {}
    for key, value in values.items():
        if isinstance(value, dict):
            clean[str(key)] = plain_count_dict(value)
        else:
            clean[str(key)] = int(value)
    return clean


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--crop", choices=["tomato", "potato"], default="tomato")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--hash-threshold", type=int, default=4)
    parser.add_argument("--val-size", type=float, default=0.15)
    parser.add_argument("--test-size", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    crop_config = get_crop_config(args.crop)
    image_rows = image_paths_for_classes(args.data_root, crop_config.classes)
    if not image_rows:
        raise ValueError("No images found.")

    hashes = [compute_hash(path) for path, _ in tqdm(image_rows, desc="Hashing images")]
    labels = [label for _, label in image_rows]
    group_ids = group_near_duplicates(hashes, args.hash_threshold)
    splits = assign_splits(labels, group_ids, args.val_size, args.test_size, args.seed)

    manifest = pd.DataFrame(
        {
            "path": [str(path) for path, _ in image_rows],
            "class_name": labels,
            "hash": hashes,
            "group_id": group_ids,
            "split": splits,
        }
    )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(args.out, index=False)

    group_sizes = manifest.groupby("group_id").size()
    duplicate_groups = group_sizes[group_sizes > 1]
    report = {
        "crop": args.crop,
        "classes": crop_config.classes,
        "hash_threshold": args.hash_threshold,
        "images": int(len(manifest)),
        "groups": int(group_sizes.size),
        "duplicate_groups": int(duplicate_groups.size),
        "images_in_duplicate_groups": int(duplicate_groups.sum()),
        "split_counts": plain_count_dict(manifest["split"].value_counts().to_dict()),
        "class_split_counts": plain_count_dict(
            manifest.groupby(["class_name", "split"]).size().unstack(fill_value=0).to_dict()
        ),
    }
    report_path = args.out.with_name(args.out.stem + "_report.json")
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

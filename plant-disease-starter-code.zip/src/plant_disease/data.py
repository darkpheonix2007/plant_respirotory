from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

from .config import COMMON_PLANTDOC_ALIASES, IMAGE_EXTENSIONS


def list_images(root: Path) -> list[Path]:
    return sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def image_transform(image_size: int = 224, train: bool = False) -> transforms.Compose:
    if train:
        return transforms.Compose(
            [
                transforms.Resize((image_size + 32, image_size + 32)),
                transforms.RandomResizedCrop(image_size, scale=(0.75, 1.0)),
                transforms.RandomHorizontalFlip(),
                transforms.RandomRotation(20),
                transforms.ColorJitter(brightness=0.15, contrast=0.15, saturation=0.15),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ]
        )
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )


class ManifestDataset(Dataset):
    def __init__(
        self,
        manifest: pd.DataFrame,
        class_to_idx: dict[str, int],
        transform: Callable | None = None,
    ) -> None:
        self.manifest = manifest.reset_index(drop=True).copy()
        self.class_to_idx = class_to_idx
        self.transform = transform

    def __len__(self) -> int:
        return len(self.manifest)

    def __getitem__(self, index: int):
        row = self.manifest.iloc[index]
        image = Image.open(row["path"]).convert("RGB")
        if self.transform:
            image = self.transform(image)
        label = self.class_to_idx[row["class_name"]]
        return image, label, row["path"]


def read_manifest(split_csv: Path, split: str | None = None) -> pd.DataFrame:
    manifest = pd.read_csv(split_csv)
    required = {"path", "class_name"}
    missing = required - set(manifest.columns)
    if missing:
        raise ValueError(f"Manifest is missing columns: {sorted(missing)}")
    if split is not None:
        if "split" not in manifest.columns:
            raise ValueError("Manifest has no 'split' column.")
        manifest = manifest[manifest["split"] == split].copy()
    if manifest.empty:
        raise ValueError(f"No images found for split={split!r}.")
    return manifest


def load_label_map(path: Path | None) -> dict[str, str]:
    if path is None:
        return COMMON_PLANTDOC_ALIASES.copy()
    with path.open("r", encoding="utf-8") as handle:
        custom = json.load(handle)
    aliases = COMMON_PLANTDOC_ALIASES.copy()
    aliases.update({normalize_label(k): v for k, v in custom.items()})
    return aliases


def normalize_label(label: str) -> str:
    return " ".join(label.replace("_", " ").replace("-", " ").lower().split())


def folder_manifest(
    folder: Path,
    class_names: list[str],
    label_map_path: Path | None = None,
) -> pd.DataFrame:
    aliases = load_label_map(label_map_path)
    rows = []
    for class_dir in sorted(path for path in folder.iterdir() if path.is_dir()):
        key = normalize_label(class_dir.name)
        class_name = aliases.get(key, class_dir.name)
        if class_name not in class_names:
            continue
        for image_path in list_images(class_dir):
            rows.append({"path": str(image_path.resolve()), "class_name": class_name})
    manifest = pd.DataFrame(rows)
    if manifest.empty:
        raise ValueError(
            "No matching images found. Check folder names or pass --label-map JSON."
        )
    return manifest


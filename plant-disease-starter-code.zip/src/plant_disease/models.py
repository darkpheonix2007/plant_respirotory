from __future__ import annotations

import torch
from torch import nn
from torchvision import models


class CustomCNN(nn.Module):
    def __init__(self, num_classes: int) -> None:
        super().__init__()
        self.features = nn.Sequential(
            self._block(3, 32),
            self._block(32, 64),
            self._block(64, 128),
            self._block(128, 256),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes),
        )

    @staticmethod
    def _block(in_channels: int, out_channels: int) -> nn.Sequential:
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.features(x))


def build_model(model_name: str, num_classes: int, pretrained: bool = True) -> nn.Module:
    model_name = model_name.lower()
    if model_name == "custom_cnn":
        return CustomCNN(num_classes)
    if model_name == "resnet18":
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
        model.fc = nn.Linear(model.fc.in_features, num_classes)
        return model
    if model_name == "mobilenet_v2":
        weights = models.MobileNet_V2_Weights.DEFAULT if pretrained else None
        model = models.mobilenet_v2(weights=weights)
        model.classifier[-1] = nn.Linear(model.classifier[-1].in_features, num_classes)
        return model
    raise ValueError("Use one of: custom_cnn, resnet18, mobilenet_v2")


def model_from_checkpoint(checkpoint: dict, device: torch.device | str = "cpu") -> nn.Module:
    model = build_model(checkpoint["model_name"], len(checkpoint["class_names"]), pretrained=False)
    if checkpoint.get("quantized") == "dynamic_linear":
        model = torch.quantization.quantize_dynamic(model, {nn.Linear}, dtype=torch.qint8)
    model.load_state_dict(checkpoint["model_state"])
    model.to(device)
    model.eval()
    return model


def gradcam_target_layer(model: nn.Module, model_name: str) -> nn.Module:
    model_name = model_name.lower()
    if model_name == "custom_cnn":
        return model.features[-2]
    if model_name == "resnet18":
        return model.layer4[-1]
    if model_name == "mobilenet_v2":
        return model.features[-1]
    raise ValueError(f"No Grad-CAM target layer configured for {model_name}.")

from __future__ import annotations

from dataclasses import dataclass


TOMATO_CLASSES = [
    "Tomato___Bacterial_spot",
    "Tomato___Early_blight",
    "Tomato___Late_blight",
    "Tomato___Leaf_Mold",
    "Tomato___Septoria_leaf_spot",
    "Tomato___Spider_mites Two-spotted_spider_mite",
    "Tomato___Target_Spot",
    "Tomato___Tomato_Yellow_Leaf_Curl_Virus",
    "Tomato___Tomato_mosaic_virus",
    "Tomato___healthy",
]

POTATO_CLASSES = [
    "Potato___Early_blight",
    "Potato___Late_blight",
    "Potato___healthy",
]


COMMON_PLANTDOC_ALIASES = {
    "tomato bacterial spot leaf": "Tomato___Bacterial_spot",
    "tomato early blight leaf": "Tomato___Early_blight",
    "tomato leaf late blight": "Tomato___Late_blight",
    "tomato late blight leaf": "Tomato___Late_blight",
    "tomato leaf mold": "Tomato___Leaf_Mold",
    "tomato septoria leaf spot": "Tomato___Septoria_leaf_spot",
    "tomato two spotted spider mites leaf": "Tomato___Spider_mites Two-spotted_spider_mite",
    "tomato target spot leaf": "Tomato___Target_Spot",
    "tomato yellow virus leaf": "Tomato___Tomato_Yellow_Leaf_Curl_Virus",
    "tomato mosaic virus leaf": "Tomato___Tomato_mosaic_virus",
    "tomato leaf": "Tomato___healthy",
    "potato early blight leaf": "Potato___Early_blight",
    "potato leaf early blight": "Potato___Early_blight",
    "potato late blight leaf": "Potato___Late_blight",
    "potato leaf late blight": "Potato___Late_blight",
    "potato leaf": "Potato___healthy",
}


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass(frozen=True)
class CropConfig:
    name: str
    classes: list[str]


def get_crop_config(crop: str) -> CropConfig:
    crop = crop.lower().strip()
    if crop == "tomato":
        return CropConfig(name="tomato", classes=TOMATO_CLASSES)
    if crop == "potato":
        return CropConfig(name="potato", classes=POTATO_CLASSES)
    raise ValueError(f"Unsupported crop: {crop}. Use 'tomato' or 'potato'.")


# Plant Disease Classification Starter

Starter code for the project:

- PlantVillage tomato or potato training from class folders.
- Perceptual-hash grouping so near-duplicate leaves stay in the same split.
- Custom CNN, ResNet18, and MobileNetV2 baselines.
- F1 scores, confusion matrices, Grad-CAM visualizations, Streamlit inference, and dynamic quantization.
- PlantDoc folder evaluation as the external real-world test.

The default setup uses the 10 PlantVillage tomato classes because they give a complete disease classification task and pair naturally with PlantDoc tomato images.

## Folder Layout

Put images in class folders:

```text
data/
  raw/
    plantvillage/
      Tomato___Bacterial_spot/
      Tomato___Early_blight/
      ...
      Tomato___healthy/
    plantdoc/
      Tomato Early blight leaf/
      Tomato leaf late blight/
      ...
```

PlantDoc folder names vary between releases. The evaluator includes a small alias map for common tomato and potato names. If your folder names do not match, pass a JSON label map.

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -e .
```

If pretrained torchvision weights cannot be downloaded in your environment, add `--no-pretrained` to training.

## 1. Create A Hash-Based Split

Tomato, default 10 classes:

```bash
python scripts/make_split.py ^
  --data-root data/raw/plantvillage ^
  --crop tomato ^
  --out data/splits/tomato_hash_split.csv
```

Potato:

```bash
python scripts/make_split.py ^
  --data-root data/raw/plantvillage ^
  --crop potato ^
  --out data/splits/potato_hash_split.csv
```

Outputs:

- `*_hash_split.csv`: one image per row with `train`, `val`, or `test`.
- `*_hash_report.json`: duplicate-group counts and split sizes for the report.

## 2. Train Models

```bash
python scripts/train.py --split-csv data/splits/tomato_hash_split.csv --model custom_cnn --epochs 15
python scripts/train.py --split-csv data/splits/tomato_hash_split.csv --model resnet18 --epochs 15
python scripts/train.py --split-csv data/splits/tomato_hash_split.csv --model mobilenet_v2 --epochs 15
```

Checkpoints and metrics are saved under `runs/<run-name>/`.

## 3. Evaluate PlantVillage Holdout

```bash
python scripts/evaluate.py ^
  --checkpoint runs/resnet18/best.pt ^
  --split-csv data/splits/tomato_hash_split.csv ^
  --split test ^
  --out runs/resnet18/test_eval
```

## 4. Evaluate PlantDoc As External Test

```bash
python scripts/evaluate.py ^
  --checkpoint runs/resnet18/best.pt ^
  --folder data/raw/plantdoc ^
  --crop tomato ^
  --out runs/resnet18/plantdoc_eval
```

The main report result is the gap between PlantVillage test F1 and PlantDoc F1.

## 5. Grad-CAM

```bash
python scripts/gradcam.py ^
  --checkpoint runs/resnet18/best.pt ^
  --image data/raw/plantdoc/Tomato Early blight leaf/example.jpg ^
  --out runs/resnet18/gradcam_example.jpg
```

## 6. Quantize

```bash
python scripts/quantize.py ^
  --checkpoint runs/resnet18/best.pt ^
  --out runs/resnet18/resnet18_dynamic_quantized.pt
```

Dynamic quantization mainly shrinks the classifier layers. For a deployment report, compare model size and inference latency before and after quantization.

## 7. Streamlit App

```bash
streamlit run app.py -- --checkpoint runs/resnet18/best.pt
```

Upload a leaf image and the app shows the top predictions.


from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import streamlit as st
import torch
from PIL import Image

from plant_disease.data import image_transform
from plant_disease.models import model_from_checkpoint


@st.cache_resource
def load_model(checkpoint_path: str):
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    model = model_from_checkpoint(checkpoint)
    return model, checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    st.set_page_config(page_title="Plant Disease Classifier", layout="centered")
    st.title("Plant Disease Classifier")

    model, checkpoint = load_model(str(args.checkpoint))
    class_names = checkpoint["class_names"]
    upload = st.file_uploader("Upload a leaf image", type=["jpg", "jpeg", "png", "webp"])
    if upload is None:
        return

    image = Image.open(upload).convert("RGB")
    st.image(image, use_container_width=True)
    transform = image_transform(checkpoint.get("image_size", 224), train=False)
    tensor = transform(image).unsqueeze(0)
    with torch.no_grad():
        probs = torch.softmax(model(tensor), dim=1).squeeze()
    top_probs, top_indices = torch.topk(probs, k=min(5, len(class_names)))
    rows = [
        {"class": class_names[int(idx)], "confidence": float(prob)}
        for prob, idx in zip(top_probs, top_indices)
    ]
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)


if __name__ == "__main__":
    main()
